<?php
//database_connection.php

$connect = new PDO('mysql:host=mysql.hostinger.ph;dbname=u253264078_new', 'u253264078_new', 'bcqrr2018');
session_start();

?>